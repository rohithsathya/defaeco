export interface DefaecoArea{
    id:string;
    name:string;
    code:number;
    city:string;
}