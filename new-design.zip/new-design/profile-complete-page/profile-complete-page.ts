import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'app-profile-complete-page',
    templateUrl: 'profile-complete-page.html',
    styleUrls: ['profile-complete-page.scss']
})
export class AppProfileCompletePage implements OnInit{

    constructor(){}
    ngOnInit(){}
}